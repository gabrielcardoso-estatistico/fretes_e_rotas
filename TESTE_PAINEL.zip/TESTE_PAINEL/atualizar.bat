@echo off
REM Atualiza dados e painel de fretes MT. Pode ser agendado no Agendador de Tarefas do Windows.
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
python atualizar.py
if "%1"=="" start "" "painel\painel_fretes_mt.html"
