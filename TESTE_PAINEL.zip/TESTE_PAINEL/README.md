# Painel de Fretes e Rotas — MT ↔ outros estados (soja, milho, algodão, feijão, etanol de milho, fertilizantes)

Coleta automática das fontes públicas, cálculo de rotas e fretes dos corredores e painel HTML.

```
pip install -r requirements.txt
python atualizar.py        # ou duplo clique em atualizar.bat
```

`atualizar.py` baixa todas as fontes, recalcula rotas e fretes e regera o painel
`painel/painel_fretes_mt.html` (arquivo único, abre direto no navegador, funciona offline).
Cada execução grava um log em `logs/`. Se algo falhar, o painel anterior é mantido.

Para rodar só uma etapa: `python pipeline.py` (dados) ou `python -m src.painel` (painel).

### Agendamento mensal (Windows)

```
schtasks /Create /TN "Painel Fretes MT" /SC MONTHLY /D 15 /ST 08:00 /TR "C:\Users\gabriel.cardoso\Desktop\TESTE_PAINEL\atualizar.bat agendado"
```
(ajuste o caminho se mover a pasta; o argumento `agendado` evita abrir o navegador ao final.)

## Painel

Filtros (cultura, veículo, origem, eixo, corredor) aplicam-se a todo o painel. Conteúdo:
indicadores-resumo, praticado × piso por corredor, diferença % sobre o piso (⚠ abaixo do piso),
frete × distância com a reta do piso, mapa das rotas, série histórica nominal e real (IPCA),
tabela ordenável e quadro de fontes. Todo card mostra fonte e data de atualização.

## Fontes (todas públicas, baixadas a cada execução)

| Dado | Fonte | Atualização |
|---|---|---|
| Frete rodoviário de grãos observado (R$/t, mensal, desde 2014) | Conab — Portal de Informações, `Frete.txt` | mensal |
| Piso mínimo de frete (CCD R$/km, CC R$) | ANTT — Res. 5.867/2020, Anexo II consolidado (redação vigente detectada automaticamente) | quando a ANTT reajusta |
| Produção municipal (t) | IBGE/SIDRA — PAM, tabela 5457 | anual |
| Contorno das UFs (mapa) | IBGE — API de malhas | estável |
| Coordenadas dos municípios | base `kelvins/municipios-brasileiros` (códigos IBGE) | estável |
| Rota, distância e tempo | OSRM sobre OpenStreetMap (servidor público, com cache em `data/cache`) | sob demanda |
| Deflator | BCB/SGS 433 — IPCA | mensal |

Se uma fonte estiver fora do ar, o pipeline usa a última cópia salva em `data/raw`.

## Metodologia

- **Corredores**: todas as rotas da pesquisa Conab com origem MT, destino fora de MT e cotação nos últimos 12 meses (novos corredores entram sozinhos). Classificação por eixo/tipo de destino em `config.yaml`.
- **Frete de mercado**: último valor Conab, média/mín/máx 12 meses, variação anual e média histórica deflacionada pelo IPCA.
- **Piso ANTT** (Tabela A, lotação): `(distância_rota × CCD + CC) / carga útil`. Pedágio não incluso.
  - Soja/milho: granel sólido, bitrem 7 eixos (37 t) e rodotrem 9 eixos (48 t).
  - Algodão: carga geral (fardos), bitrem 7 eixos (30 t), apenas Santos e Paranaguá.
  - Feijão: carga geral (sacaria), bitrem 37 t; 5 maiores produtores de MT (IBGE) → São Paulo, Belo Horizonte, Goiânia.
  - Etanol de milho: carga perigosa a granel líquido, bitrem tanque 45 m³ / rodotrem 60 m³; usinas (Lucas do Rio Verde, Sorriso,
    Sinop, Nova Mutum, Primavera do Leste) → Paulínia, Senador Canedo, Porto Velho. Sem retorno vazio (`retorno_vazio` no config).
  - Fertilizantes (entrada em MT): granel sólido; Paranaguá, Santos, Itaqui e Miritituba → 6 maiores produtores de soja (IBGE).
- **Rotas próprias**: produtos sem frete Conab usam `rotas` no `config.yaml` (lista de locais `MUNICIPIO-UF` ou `{top_pam: cultura, n: N}`
  para pegar automaticamente os maiores produtores do IBGE). Para incluir outro produto basta uma nova entrada em `culturas`.
- **Conversões**: R$/saca 60 kg (grãos) e R$/arroba 15 kg (algodão).
- **Controle de qualidade**: `alerta_distancia` marca rotas onde a distância Conab difere > 15% da rota OSRM.

## Limitações

- A Conab não separa o frete por cultura: soja e milho recebem o mesmo frete de mercado.
- Não há série pública de frete praticado para algodão, feijão, etanol e fertilizantes; para eles só é calculado o piso ANTT.
- Origens/destinos de feijão, etanol e fertilizantes são premissas (usinas, bases e centros de consumo) editáveis no config.
- Cargas úteis e veículos são premissas editáveis em `config.yaml`.

## Saídas (`data/processed/`)

- `corredores.csv`: um corredor por linha (distâncias, tempo, indicadores de mercado)
- `fretes_por_cultura.csv`: cultura × corredor × veículo (mercado, piso, spread, R$/unidade, produção na origem)
- `fretes_historico_conab.csv`: série mensal completa MT → outras UFs (nominal e real)
- `piso_antt.csv`: coeficientes vigentes (todas as cargas e eixos)
- `producao_mt.csv`: PAM por município de MT
- `rotas.geojson`: traçado das rotas para o mapa
- `metadados.json`: data de execução e referência de cada fonte
