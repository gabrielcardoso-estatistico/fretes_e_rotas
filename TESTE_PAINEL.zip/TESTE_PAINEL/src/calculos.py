"""Cálculo dos corredores, indicadores de frete de mercado e piso mínimo ANTT."""
import pandas as pd

from .fontes import normaliza


def classifica_destinos(df: pd.DataFrame, destinos_cfg: dict) -> pd.DataFrame:
    cfg = {normaliza(k): v for k, v in destinos_cfg.items()}
    df = df.copy()
    df["tipo_destino"] = df.destino.map(lambda d: cfg.get(d, {}).get("tipo", "outro"))
    df["eixo"] = df.destino.map(lambda d: cfg.get(d, {}).get("eixo", "Outros"))
    df["descricao_destino"] = df.destino.map(lambda d: cfg.get(d, {}).get("descricao", ""))
    return df


def deflaciona(df: pd.DataFrame, ipca: pd.DataFrame, col: str = "frete_rs_t") -> pd.DataFrame:
    """Adiciona <col>_real a preços do último mês com IPCA disponível."""
    base = ipca.indice.iloc[-1]
    df = df.merge(ipca, on="data", how="left")
    df[f"{col}_real"] = df[col] * base / df.indice
    return df.drop(columns="indice")


def corredores_ativos(hist: pd.DataFrame, janela_meses: int) -> pd.DataFrame:
    """Rotas da pesquisa Conab com cotação recente e seus indicadores de mercado."""
    pesq = hist[hist.fonte == "PESQUISA"]
    corte = pesq.data.max() - pd.DateOffset(months=janela_meses - 1)
    linhas = []
    for (orig, dest), g in pesq.groupby(["origem", "destino"]):
        g = g.sort_values("data")
        ult = g.iloc[-1]
        if ult.data < corte:
            continue
        ult12 = g[g.data > ult.data - pd.DateOffset(months=12)]
        ano_ant = g[g.data == ult.data - pd.DateOffset(years=1)]
        linhas.append({
            "origem": orig, "cod_ibge_origem": ult.cod_ibge_origem,
            "destino": dest, "cod_ibge_destino": ult.cod_ibge_destino, "uf_destino": ult.uf_destino,
            "tipo_destino": ult.tipo_destino, "eixo": ult.eixo, "descricao_destino": ult.descricao_destino,
            "distancia_conab_km": ult.distancia_km,
            "data_ultima_cotacao": ult.data.date(),
            "frete_mercado_rs_t": ult.frete_rs_t,
            "frete_mercado_rs_tkm": ult.frete_rs_t / ult.distancia_km,
            "frete_media_12m_rs_t": ult12.frete_rs_t.mean(),
            "frete_min_12m_rs_t": ult12.frete_rs_t.min(),
            "frete_max_12m_rs_t": ult12.frete_rs_t.max(),
            "var_12m_pct": (ult.frete_rs_t / ano_ant.frete_rs_t.iloc[0] - 1) * 100 if len(ano_ant) else None,
            "frete_media_hist_real_rs_t": g.frete_rs_t_real.mean(),
            "n_meses_serie": len(g),
            "inicio_serie": g.data.min().date(),
        })
    return pd.DataFrame(linhas)


def _locais(spec, producao: pd.DataFrame, coords: pd.DataFrame) -> list[dict]:
    """Resolve a lista de locais de uma rota: nomes 'MUNICIPIO-UF' ou {top_pam: cultura, n: N}."""
    if isinstance(spec, dict) and "top_pam" in spec:
        p = producao[producao.cultura == spec["top_pam"]].dropna(subset=["producao_t"])
        p = p[p.cod_ibge.isin(coords.cod_ibge)].nlargest(spec["n"], "producao_t")  # ignora municípios sem coordenada
        chaves = coords.set_index("cod_ibge").loc[p.cod_ibge.astype(int), "chave"].tolist()
        return [{"local": c} for c in chaves]
    return [x if isinstance(x, dict) else {"local": x} for x in spec]


def corredores_especificos(culturas: dict, catalogo: dict, producao: pd.DataFrame,
                           coords: pd.DataFrame) -> pd.DataFrame:
    """Rotas definidas no config para produtos sem frete Conab (feijão, etanol, fertilizantes...)."""
    cat = {normaliza(k): v for k, v in catalogo.items()}
    por_chave = coords.set_index("chave")
    linhas = []
    for cultura, cfg in culturas.items():
        if "rotas" not in cfg:
            continue
        entrada = cfg.get("sentido") == "entrada"
        origens = _locais(cfg["rotas"]["origens"], producao, coords)
        destinos = _locais(cfg["rotas"]["destinos"], producao, coords)
        for o in origens:
            for d in destinos:
                oc, dc = normaliza(o["local"]), normaliza(d["local"])
                if oc not in por_chave.index or dc not in por_chave.index:
                    print(f"  ! local não encontrado na base IBGE: {oc if oc not in por_chave.index else dc}")
                    continue
                externo = o if entrada else d  # o ponto fora de MT define eixo/tipo
                info = {**cat.get(normaliza(externo["local"]), {}), **externo}
                linhas.append({
                    "cultura_especifica": cultura, "origem": oc, "cod_ibge_origem": por_chave.loc[oc, "cod_ibge"],
                    "destino": dc, "cod_ibge_destino": por_chave.loc[dc, "cod_ibge"], "uf_destino": por_chave.loc[dc, "uf"],
                    "tipo_destino": info.get("tipo", "outro"), "eixo": info.get("eixo", "Outros"),
                    "descricao_destino": info.get("descricao", ""),
                })
    return pd.DataFrame(linhas)


def piso_antt_rs_t(piso: pd.DataFrame, tipo_carga: str, eixos: int, distancia_km: float,
                   carga_util_t: float, retorno_vazio: bool = False) -> float:
    """Piso mínimo (Tabela A, lotação): (km × CCD + CC) / carga útil.
    Com retorno vazio obrigatório soma 92% × CCD × km (Res. 5.867, art. 5º §6º)."""
    linha = piso[(piso.tipo_carga.map(normaliza) == normaliza(tipo_carga)) & (piso.eixos == eixos)]
    if linha.empty:
        raise ValueError(f"Sem coeficiente ANTT para {tipo_carga} / {eixos} eixos")
    r = linha.iloc[0]
    retorno = 0.92 * r.CCD * distancia_km if retorno_vazio else 0
    return (distancia_km * r.CCD + r.CC + retorno) / carga_util_t


def fretes_por_cultura(corr: pd.DataFrame, culturas: dict, piso: pd.DataFrame,
                       producao: pd.DataFrame) -> pd.DataFrame:
    """Uma linha por cultura × corredor × veículo de referência."""
    total_mt = producao.groupby("cultura").producao_t.sum()
    linhas = []
    for cultura, cfg in culturas.items():
        usa_conab = cfg.get("usa_frete_conab", True)
        if "rotas" in cfg:
            sub = corr[corr.cultura_especifica == cultura]
        else:
            sub = corr[corr.cultura_especifica.isna() & corr.tipo_destino.isin(cfg["tipos_destino"])]
            if cfg.get("destinos"):
                sub = sub[sub.destino.isin([normaliza(d) for d in cfg["destinos"]])]
        prod = producao[producao.cultura == cultura].set_index("cod_ibge").producao_t
        for _, c in sub.iterrows():
            dist = c.distancia_rota_km if pd.notna(c.distancia_rota_km) else c.distancia_conab_km
            prod_orig = prod.get(c.cod_ibge_origem)
            for v in cfg["veiculos"]:
                piso_t = piso_antt_rs_t(piso, cfg["tipo_carga_antt"], v["eixos"], dist, v["carga_util_t"],
                                        cfg.get("retorno_vazio", False))
                mercado = c.frete_mercado_rs_t if usa_conab else None
                linhas.append({
                    "cultura": cultura,
                    **c.drop(labels=["geometria"], errors="ignore").to_dict(),
                    "frete_mercado_rs_t": mercado,
                    "frete_media_12m_rs_t": c.frete_media_12m_rs_t if usa_conab else None,
                    "veiculo": v["nome"], "eixos": v["eixos"], "carga_util_t": v["carga_util_t"],
                    "tipo_carga_antt": cfg["tipo_carga_antt"],
                    "piso_antt_rs_t": piso_t,
                    "piso_antt_rs_viagem": piso_t * v["carga_util_t"],
                    "mercado_vs_piso_pct": (mercado / piso_t - 1) * 100 if mercado else None,
                    "unidade": cfg["unidade"]["nome"],
                    "frete_mercado_rs_unid": mercado * cfg["unidade"]["t"] if mercado else None,
                    "piso_antt_rs_unid": piso_t * cfg["unidade"]["t"],
                    "producao_origem_t": prod_orig,
                    "participacao_origem_mt_pct": (prod_orig / total_mt[cultura] * 100
                                                   if prod_orig is not None and pd.notna(prod_orig) else None),
                    "sentido": cfg.get("sentido", "saida"),
                })
    return pd.DataFrame(linhas)
