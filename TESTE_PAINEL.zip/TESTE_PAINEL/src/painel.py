"""Gera o painel HTML (arquivo único, abre no navegador) a partir de data/processed."""
import json
from pathlib import Path

import pandas as pd
import yaml
from plotly.offline import get_plotlyjs

RAIZ = Path(__file__).resolve().parents[1]
PROC = RAIZ / "data" / "processed"
RAW = RAIZ / "data" / "raw"
SAIDA = RAIZ / "painel" / "painel_fretes_mt.html"
TEMPLATE = Path(__file__).with_name("painel_template.html")

CULTURAS_ROTULO = {"soja": "Soja", "milho": "Milho", "algodao": "Algodão"}  # demais vêm de "rotulo" no config


def _nomes_municipios() -> dict:
    m = pd.read_csv(RAW / "municipios.csv")
    # UF pelos 2 primeiros dígitos do código IBGE
    siglas = {11: "RO", 12: "AC", 13: "AM", 14: "RR", 15: "PA", 16: "AP", 17: "TO", 21: "MA", 22: "PI",
              23: "CE", 24: "RN", 25: "PB", 26: "PE", 27: "AL", 28: "SE", 29: "BA", 31: "MG", 32: "ES",
              33: "RJ", 35: "SP", 41: "PR", 42: "SC", 43: "RS", 50: "MS", 51: "MT", 52: "GO", 53: "DF"}
    return {int(r.codigo_ibge): f"{r.nome}/{siglas[int(r.codigo_ibge) // 100000]}" for r in m.itertuples()}


def _registros(df: pd.DataFrame) -> list[dict]:
    """DataFrame -> lista de dicts JSON-safe (NaN vira null)."""
    return json.loads(df.to_json(orient="records", date_format="iso", force_ascii=False))


def gerar() -> Path:
    cfg = yaml.safe_load((RAIZ / "config.yaml").read_text(encoding="utf-8"))
    meta = json.loads((PROC / "metadados.json").read_text(encoding="utf-8"))
    nomes = _nomes_municipios()

    fretes = pd.read_csv(PROC / "fretes_por_cultura.csv")
    corr = pd.read_csv(PROC / "corredores.csv")
    hist = pd.read_csv(PROC / "fretes_historico_conab.csv", parse_dates=["data"])
    piso = pd.read_csv(PROC / "piso_antt.csv")
    geo = json.loads((PROC / "rotas.geojson").read_text(encoding="utf-8"))
    coords = pd.read_csv(RAW / "municipios.csv").set_index("codigo_ibge")

    def rotulo(o, d):
        return f"{nomes[int(o)].split('/')[0]} → {nomes[int(d)]}"

    for df in (fretes, corr):
        df["corredor"] = [rotulo(o, d) for o, d in zip(df.cod_ibge_origem, df.cod_ibge_destino)]
        df["origem_nome"] = [nomes[int(o)] for o in df.cod_ibge_origem]
        df["destino_nome"] = [nomes[int(d)] for d in df.cod_ibge_destino]

    # Série histórica só dos corredores ativos, fonte pesquisa
    ativos = pd.MultiIndex.from_frame(corr[["origem", "destino"]])
    eh_ativo = pd.MultiIndex.from_frame(hist[["origem", "destino"]]).isin(ativos)
    h = hist[(hist.fonte == "PESQUISA").to_numpy() & eh_ativo].copy()
    h["corredor"] = [rotulo(o, d) for o, d in zip(h.cod_ibge_origem, h.cod_ibge_destino)]
    h["mes"] = h.data.dt.strftime("%Y-%m")
    h = h[["corredor", "mes", "frete_rs_t", "frete_rs_t_real"]].round(2)

    # Retas de piso (R$/t em função do km) por cultura × veículo
    linhas_piso = []
    for cultura, c in cfg["culturas"].items():
        for v in c["veiculos"]:
            p = piso[(piso.tipo_carga == c["tipo_carga_antt"]) & (piso.eixos == v["eixos"])].iloc[0]
            linhas_piso.append({"cultura": cultura, "veiculo": v["nome"], "carga_util_t": v["carga_util_t"],
                                "CCD": p.CCD, "CC": p.CC, "tipo_carga": c["tipo_carga_antt"]})

    # Pontos de origem/destino para o mapa
    pontos = []
    override = {k: v for k, v in (cfg.get("coord_override") or {}).items()}
    def xy(nome, cod):
        return override.get(nome, (coords.loc[cod, "longitude"], coords.loc[cod, "latitude"]))

    for r in corr.drop_duplicates("origem").itertuples():
        lon, lat = xy(r.origem, r.cod_ibge_origem)
        pontos.append({"tipo": "origem", "nome": r.origem_nome, "lon": lon, "lat": lat})
    for r in corr.drop_duplicates("destino").itertuples():
        lon, lat = xy(r.destino, r.cod_ibge_destino)
        pontos.append({"tipo": "destino", "nome": f"{r.destino_nome} — {r.descricao_destino}", "lon": lon, "lat": lat})

    rota_por_par = {(f["properties"]["origem"], f["properties"]["destino"]): f["geometry"]["coordinates"]
                    for f in geo["features"]}
    corr["coords"] = [rota_por_par.get((o, d)) for o, d in zip(corr.origem, corr.destino)]

    lon, lat = [], []
    for ft in json.loads((RAW / "ibge_malha_ufs.geojson").read_text(encoding="utf-8"))["features"]:
        g = ft["geometry"]
        poligonos = [g["coordinates"]] if g["type"] == "Polygon" else g["coordinates"]
        for anel in (a for pol in poligonos for a in pol):
            lon += [round(x, 3) for x, _ in anel] + [None]
            lat += [round(y, 3) for _, y in anel] + [None]

    dados = {
        "ufs": {"lon": lon, "lat": lat},
        "meta": meta,
        "culturas": [{"id": k, "rotulo": v.get("rotulo") or CULTURAS_ROTULO.get(k, k), "unidade": v["unidade"]["nome"],
                      "veiculos": [x["nome"] for x in v["veiculos"]],
                      "usa_conab": v.get("usa_frete_conab", True), "grupo": v.get("grupo", ""),
                      "nota": v.get("nota"), "sentido": v.get("sentido", "saida"),
                      "tipo_carga": v["tipo_carga_antt"]} for k, v in cfg["culturas"].items()],
        "fretes": _registros(fretes.round(4)),
        "corredores": _registros(corr[["corredor", "origem_nome", "destino_nome", "eixo", "coords",
                                       "frete_mercado_rs_t", "distancia_rota_km"]]),
        "historico": _registros(h),
        "linhas_piso": linhas_piso,
        "pontos": pontos,
    }

    html = TEMPLATE.read_text(encoding="utf-8")
    html = html.replace("/*__PLOTLY__*/", get_plotlyjs())
    html = html.replace("/*__DADOS__*/null", json.dumps(dados, ensure_ascii=False).replace("</", "<\\/"))
    SAIDA.parent.mkdir(exist_ok=True)
    SAIDA.write_text(html, encoding="utf-8")
    return SAIDA


if __name__ == "__main__":
    print(gerar())
