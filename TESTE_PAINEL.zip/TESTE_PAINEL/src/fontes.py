"""Coleta das fontes públicas. Cada função baixa, salva o bruto em data/raw e devolve DataFrame limpo."""
import html as htmllib
import io
import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path

import pandas as pd
import requests

RAW = Path(__file__).resolve().parents[1] / "data" / "raw"
RAW.mkdir(parents=True, exist_ok=True)

HEADERS = {"User-Agent": "painel-fretes-mt/1.0 (dados publicos)"}


def normaliza(txt: str) -> str:
    """'SANTARÉM-PA ' -> 'SANTAREM-PA'"""
    txt = unicodedata.normalize("NFKD", str(txt)).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", txt).strip().upper()


# Por arquivo: quando foi coletado, se veio da rede ou do cache, e o Last-Modified do servidor
COLETA: dict[str, dict] = {}


def _baixar(url: str, destino: Path, timeout=180) -> bytes:
    """Baixa e salva; se falhar, usa a última cópia salva."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=timeout)
        r.raise_for_status()
        destino.write_bytes(r.content)
        COLETA[destino.name] = {"coletado_em": carimbo(), "origem": "rede",
                                "last_modified": r.headers.get("Last-Modified")}
        return r.content
    except requests.RequestException as e:
        if destino.exists():
            print(f"  ! falha ao baixar {url} ({e}); usando cópia local de {destino.name}")
            COLETA[destino.name] = {"coletado_em": datetime.fromtimestamp(destino.stat().st_mtime)
                                    .isoformat(timespec="seconds"), "origem": "cache local"}
            return destino.read_bytes()
        raise


# ---------------------------------------------------------------- Conab
def conab_fretes(url: str) -> pd.DataFrame:
    """Série mensal de fretes rodoviários de grãos (R$/t) — Conab/SIAGRO."""
    conteudo = _baixar(url, RAW / "conab_Frete.txt")
    df = pd.read_csv(io.BytesIO(conteudo), sep=";", encoding="latin-1", dtype=str)
    df = df.apply(lambda s: s.str.strip())
    for col in ["valor_frete_tonelada", "valor_tonelada_km"]:
        df[col] = pd.to_numeric(df[col].str.replace(",", "."), errors="coerce")
    for col in ["ano", "mes", "distancia_km", "cod_ibge_origem", "cod_ibge_destino"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")
    df["data"] = pd.to_datetime(dict(year=df.ano, month=df.mes, day=1))
    df["origem"] = df.municipio_origem.map(normaliza)
    df["destino"] = df.municipio_destino.map(normaliza)
    df = df.rename(columns={"dsc_fonte": "fonte", "valor_frete_tonelada": "frete_rs_t",
                            "valor_tonelada_km": "frete_rs_tkm"})
    return df[["fonte", "origem", "cod_ibge_origem", "uf_origem", "destino", "cod_ibge_destino",
               "uf_destino", "data", "distancia_km", "frete_rs_t", "frete_rs_tkm"]]


# ---------------------------------------------------------------- ANTT
def antt_piso_minimo(url: str) -> tuple[pd.DataFrame, str]:
    """Tabela A (carga lotação) do Anexo II da Res. ANTT 5.867/2020, texto consolidado vigente.

    Retorna (tabela longa tipo_carga × eixos com CCD e CC, resolução que deu a redação atual).
    """
    html = _baixar(url, RAW / "antt_res5867.html").decode("latin-1")
    redacoes = re.findall(r"Reda&ccedil;&atilde;o dada pela <a[^>]*>([^<]+)</a>", html)
    resolucao = htmllib.unescape(redacoes[-1]) if redacoes else "desconhecida"

    tab = pd.read_html(io.StringIO(html), decimal=",", thousands=".")[0]  # Tabela A
    eixos = tab.iloc[1, 4:].astype(int).tolist()
    tab = tab.iloc[2:].copy()
    tab[1] = tab[1].ffill()
    linhas = []
    for _, r in tab.iterrows():
        coef = "CCD" if "Deslocamento" in str(r[2]) else "CC"
        for i, e in enumerate(eixos):
            linhas.append({"tipo_carga": r[1], "coef": coef, "eixos": e, "valor": r[4 + i]})
    longa = pd.DataFrame(linhas)
    longa["valor"] = pd.to_numeric(longa["valor"], errors="coerce")
    longa = longa.dropna(subset=["valor"])
    piso = longa.pivot_table(index=["tipo_carga", "eixos"], columns="coef", values="valor").reset_index()
    piso.columns.name = None
    piso["resolucao"] = resolucao
    return piso, resolucao


# ---------------------------------------------------------------- IBGE
def ibge_producao_municipal(base_url: str, uf_cod: int, produtos: dict[str, int]) -> pd.DataFrame:
    """PAM (SIDRA 5457) — quantidade produzida (t) por município, último ano disponível."""
    codigos = ",".join(str(c) for c in produtos.values())
    url = f"{base_url}/t/5457/n6/in%20n3%20{uf_cod}/v/214/p/last/c782/{codigos}?formato=json"
    dados = json.loads(_baixar(url, RAW / "ibge_pam_5457.json"))
    df = pd.DataFrame(dados[1:])
    cod_para_cultura = {str(v): k for k, v in produtos.items()}
    df = pd.DataFrame({
        "cod_ibge": pd.to_numeric(df["D1C"]).astype("Int64"),
        "municipio": df["D1N"],
        "ano": pd.to_numeric(df["D3C"]),
        "cultura": df["D4C"].map(cod_para_cultura),
        "producao_t": pd.to_numeric(df["V"], errors="coerce"),  # '-', '...' viram NaN
    })
    return df


SIGLAS_UF = {11: "RO", 12: "AC", 13: "AM", 14: "RR", 15: "PA", 16: "AP", 17: "TO", 21: "MA", 22: "PI",
             23: "CE", 24: "RN", 25: "PB", 26: "PE", 27: "AL", 28: "SE", 29: "BA", 31: "MG", 32: "ES",
             33: "RJ", 35: "SP", 41: "PR", 42: "SC", 43: "RS", 50: "MS", 51: "MT", 52: "GO", 53: "DF"}


def municipios_coordenadas(url: str) -> pd.DataFrame:
    df = pd.read_csv(io.BytesIO(_baixar(url, RAW / "municipios.csv")))
    df = df.rename(columns={"codigo_ibge": "cod_ibge"})[["cod_ibge", "nome", "latitude", "longitude"]]
    df["uf"] = (df.cod_ibge // 100000).map(SIGLAS_UF)
    df["chave"] = df.nome.map(normaliza) + "-" + df.uf  # mesmo formato da Conab: 'SAO PAULO-SP'
    return df


def ibge_malha_ufs(url: str) -> dict:
    """Contorno das UFs (GeoJSON, qualidade mínima) para o mapa do painel."""
    return json.loads(_baixar(url, RAW / "ibge_malha_ufs.geojson"))


# ---------------------------------------------------------------- BCB
def ipca_indice(url: str) -> pd.DataFrame:
    """Número-índice do IPCA mensal (base arbitrária) a partir da variação % (SGS 433)."""
    s = pd.DataFrame(json.loads(_baixar(url, RAW / "bcb_ipca_433.json")))
    s["data"] = pd.to_datetime(s["data"], format="%d/%m/%Y")
    s["indice"] = (1 + pd.to_numeric(s["valor"]) / 100).cumprod()
    return s[["data", "indice"]]


def carimbo() -> str:
    return datetime.now().isoformat(timespec="seconds")
