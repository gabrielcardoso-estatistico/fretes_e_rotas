"""Roteamento rodoviário via OSRM (OpenStreetMap). Resultados ficam em cache local."""
import json
import time
from pathlib import Path

import requests

CACHE = Path(__file__).resolve().parents[1] / "data" / "cache" / "osrm"
CACHE.mkdir(parents=True, exist_ok=True)


def rota(base_url: str, origem: tuple[float, float], destino: tuple[float, float]) -> dict:
    """origem/destino em (lon, lat). Retorna distância (km), duração (h) e geometria GeoJSON."""
    chave = f"{origem[0]:.4f}_{origem[1]:.4f}__{destino[0]:.4f}_{destino[1]:.4f}.json"
    arq = CACHE / chave
    if arq.exists():
        return json.loads(arq.read_text())

    url = (f"{base_url}/route/v1/driving/{origem[0]},{origem[1]};{destino[0]},{destino[1]}"
           "?overview=simplified&geometries=geojson")
    for tentativa in range(3):
        try:
            r = requests.get(url, timeout=60)
            r.raise_for_status()
            d = r.json()
            break
        except requests.RequestException:
            time.sleep(2 * (tentativa + 1))
    else:
        raise RuntimeError(f"OSRM indisponível para {origem} -> {destino}")
    if d.get("code") != "Ok":
        raise RuntimeError(f"OSRM: {d.get('code')} {d.get('message')}")

    rt = d["routes"][0]
    res = {"distancia_km": rt["distance"] / 1000, "duracao_h": rt["duration"] / 3600,
           "geometria": rt["geometry"]}
    arq.write_text(json.dumps(res))
    time.sleep(1)  # política de uso do servidor público
    return res
