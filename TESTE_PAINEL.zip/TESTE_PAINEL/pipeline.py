"""Pipeline completo: coleta fontes públicas -> rotas -> fretes por cultura.

Uso:  python pipeline.py
Saídas em data/processed/.
"""
import json
from pathlib import Path

import pandas as pd
import yaml

from src import calculos, fontes, rotas

RAIZ = Path(__file__).resolve().parent
OUT = RAIZ / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

UF_CODIGO = {"MT": 51}


def main():
    cfg = yaml.safe_load((RAIZ / "config.yaml").read_text(encoding="utf-8"))
    f = cfg["fontes"]
    uf = cfg["uf_origem"]
    meta = {"executado_em": fontes.carimbo(), "fontes": {}}

    print("1/6 Conab — fretes de grãos")
    conab = fontes.conab_fretes(f["conab_frete"])
    meta["fontes"]["conab"] = {"url": f["conab_frete"], "ultimo_mes": str(conab.data.max().date()),
                               "ultimo_mes_origem_uf": str(conab[conab.uf_origem == uf].data.max().date())}

    print("2/6 ANTT — piso mínimo (Res. 5.867 consolidada)")
    piso, resolucao = fontes.antt_piso_minimo(f["antt_res_5867"])
    meta["fontes"]["antt"] = {"url": f["antt_res_5867"], "redacao_vigente": resolucao}

    print("3/6 IBGE — produção municipal (PAM) e coordenadas")
    produtos = {k: v["sidra_codigo"] for k, v in cfg["culturas"].items() if "sidra_codigo" in v}
    producao = fontes.ibge_producao_municipal(f["ibge_sidra"], UF_CODIGO[uf], produtos)
    coords = fontes.municipios_coordenadas(f["municipios_coord"])
    fontes.ibge_malha_ufs(f["ibge_malha_ufs"])  # usada só no mapa do painel
    meta["fontes"]["ibge_pam"] = {"tabela": 5457, "ano": int(producao.ano.max())}

    print("4/6 BCB — IPCA")
    ipca = fontes.ipca_indice(f["bcb_ipca"])
    meta["fontes"]["ipca"] = {"serie_sgs": 433, "ultimo_mes": str(ipca.data.max().date())}

    print("5/6 Corredores e rotas (OSRM)")
    hist = conab[(conab.uf_origem == uf) & (conab.uf_destino != uf)]
    hist = calculos.classifica_destinos(hist, cfg["destinos"])
    hist = calculos.deflaciona(hist, ipca)
    corr = calculos.corredores_ativos(hist, cfg["janela_corredor_ativo_meses"])
    corr["cultura_especifica"] = None
    proprios = calculos.corredores_especificos(cfg["culturas"], cfg["destinos"], producao, coords)
    print(f"  {len(corr)} corredores Conab + {len(proprios)} rotas próprias (produtos sem frete Conab)")
    corr = pd.concat([corr, proprios], ignore_index=True)

    xy = coords.set_index("cod_ibge")[["longitude", "latitude"]]
    override = {fontes.normaliza(k): tuple(v) for k, v in (cfg.get("coord_override") or {}).items()}

    def ponto(nome, cod):
        return override.get(nome) or tuple(xy.loc[int(cod)])

    res_rotas = []
    for _, c in corr.iterrows():
        try:
            r = rotas.rota(f["osrm"], ponto(c.origem, c.cod_ibge_origem), ponto(c.destino, c.cod_ibge_destino))
        except Exception as e:  # rota sem resposta não derruba o pipeline
            print(f"  ! {c.origem} -> {c.destino}: {e}")
            r = {"distancia_km": None, "duracao_h": None, "geometria": None}
        res_rotas.append(r)
    corr["distancia_rota_km"] = [r["distancia_km"] for r in res_rotas]
    corr["duracao_rota_h"] = [r["duracao_h"] for r in res_rotas]
    corr["dif_distancia_pct"] = (corr.distancia_rota_km / corr.distancia_conab_km - 1) * 100
    corr["geometria"] = [r["geometria"] for r in res_rotas]
    corr["alerta_distancia"] = corr.dif_distancia_pct.abs() > cfg["tolerancia_distancia_pct"]
    for _, c in corr[corr.alerta_distancia].iterrows():
        print(f"  ! distância Conab {c.distancia_conab_km} km x rota {c.distancia_rota_km:.0f} km: "
              f"{c.origem} -> {c.destino} (verificar dado da fonte)")

    print("6/6 Fretes por cultura")
    fretes = calculos.fretes_por_cultura(corr, cfg["culturas"], piso, producao)

    # ---- gravação
    hist.to_csv(OUT / "fretes_historico_conab.csv", index=False, encoding="utf-8-sig")
    piso.to_csv(OUT / "piso_antt.csv", index=False, encoding="utf-8-sig")
    producao.to_csv(OUT / "producao_mt.csv", index=False, encoding="utf-8-sig")
    corr.drop(columns="geometria").to_csv(OUT / "corredores.csv", index=False, encoding="utf-8-sig")
    fretes.to_csv(OUT / "fretes_por_cultura.csv", index=False, encoding="utf-8-sig")
    geo = {"type": "FeatureCollection", "features": [
        {"type": "Feature", "geometry": c.geometria,
         "properties": {k: c[k] for k in ["origem", "destino", "eixo", "tipo_destino"]}
                       | {"distancia_km": round(c.distancia_rota_km or 0, 1),
                          "frete_rs_t": c.frete_mercado_rs_t}}
        for _, c in corr.iterrows() if c.geometria]}
    (OUT / "rotas.geojson").write_text(json.dumps(geo, ensure_ascii=False), encoding="utf-8")
    arquivos = {"conab": "conab_Frete.txt", "antt": "antt_res5867.html",
                "ibge_pam": "ibge_pam_5457.json", "ipca": "bcb_ipca_433.json"}
    for fonte, arq in arquivos.items():
        meta["fontes"][fonte]["coleta"] = fontes.COLETA.get(arq)
    meta["fontes"]["osrm"] = {"url": f["osrm"], "rotas_calculadas": len(corr)}
    (OUT / "metadados.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\nOK — {len(corr)} corredores, {len(fretes)} linhas cultura×corredor×veículo em {OUT}")
    return hist, piso, producao, corr, fretes, meta


if __name__ == "__main__":
    main()
