"""Atualiza tudo: baixa as fontes, recalcula rotas/fretes e regera o painel.

Uso:  python atualizar.py            (ou dê duplo clique em atualizar.bat)
Log de cada execução em logs/.
"""
import sys
import traceback
from datetime import datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
sys.path.insert(0, str(RAIZ))
LOGS = RAIZ / "logs"
LOGS.mkdir(exist_ok=True)


class _Tee:
    """Escreve no console e no arquivo de log ao mesmo tempo."""
    def __init__(self, *alvos):
        self.alvos = alvos

    def write(self, s):
        for a in self.alvos:
            a.write(s)

    def flush(self):
        for a in self.alvos:
            a.flush()


def main() -> int:
    log = open(LOGS / f"atualizacao_{datetime.now():%Y%m%d_%H%M%S}.log", "w", encoding="utf-8")
    sys.stdout = sys.stderr = _Tee(sys.__stdout__, log)
    try:
        import pipeline
        from src import painel

        print(f"== Atualização iniciada em {datetime.now():%d/%m/%Y %H:%M}")
        pipeline.main()
        print("\n== Gerando painel")
        print(f"Painel: {painel.gerar()}")
        print("== Concluído")
        return 0
    except Exception:
        traceback.print_exc()
        print("== FALHOU — painel anterior mantido")
        return 1
    finally:
        sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__
        log.close()


if __name__ == "__main__":
    sys.exit(main())
